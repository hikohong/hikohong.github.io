/**
 * YouTube Ad Skip Auto-Clicker — MV3 content script.
 *
 * Runs at document_start in an isolated world. It only ever touches the DOM
 * (the <video> element and YouTube's own ad buttons) — it never injects script
 * into the page and never talks to the network.
 */
(() => {
  'use strict';

  const DEFAULTS = {
    enabled: true,
    clickSkip: true,
    fastForward: true,
    muteDuringAd: true,
    hideOverlays: true,
  };

  let opts = { ...DEFAULTS };

  // Selectors for the various "Skip" buttons YouTube has shipped over the years.
  // Kept broad on purpose — YouTube renames these frequently.
  const SKIP_SELECTORS = [
    '.ytp-ad-skip-button',
    '.ytp-ad-skip-button-modern',
    '.ytp-skip-ad-button',
    '.ytp-ad-skip-button-container button',
    'button[class*="ytp-ad-skip-button"]',
    'button[class*="ytp-skip-ad-button"]',
  ];

  // "Close overlay banner ad" buttons (small ads across the bottom of the video).
  const OVERLAY_CLOSE_SELECTORS = [
    '.ytp-ad-overlay-close-button',
    '.ytp-ad-overlay-close-container',
  ];

  // --- ad state -------------------------------------------------------------
  // YouTube reuses the SAME <video> element for ads and content, so anything we
  // change during an ad must be put back afterwards — otherwise the real clip
  // inherits it. That is what adActive/mutedByUs track.
  let adActive = false;
  let mutedByUs = false;
  let previousMuted = false;
  let skipped = 0;
  let flushTimer = null;

  const getPlayer = () =>
    document.getElementById('movie_player') ||
    document.querySelector('.html5-video-player');

  const getVideo = () =>
    document.querySelector('.html5-main-video') || document.querySelector('video');

  function adShowing() {
    const p = getPlayer();
    return !!p && (p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting'));
  }

  // offsetParent is unreliable inside the player (transforms/fixed positioning),
  // so measure the box instead.
  function isClickable(el) {
    if (!el || el.disabled) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    const style = getComputedStyle(el);
    return style.visibility !== 'hidden' && style.display !== 'none' && style.opacity !== '0';
  }

  function clickFirst(selectors) {
    for (const sel of selectors) {
      for (const el of document.querySelectorAll(sel)) {
        if (isClickable(el)) {
          el.click();
          return true;
        }
      }
    }
    return false;
  }

  // Persist the skip counter, batched so we are not writing on every click.
  function bumpCounter() {
    skipped += 1;
    if (flushTimer) return;
    flushTimer = setTimeout(() => {
      flushTimer = null;
      const delta = skipped;
      skipped = 0;
      try {
        chrome.storage.local.get({ skipCount: 0 }, (got) => {
          if (chrome.runtime.lastError) return;
          chrome.storage.local.set({ skipCount: (got.skipCount || 0) + delta });
        });
      } catch {
        /* extension context invalidated (reload/update) — harmless */
      }
    }, 1000);
  }

  function enterAd(video) {
    adActive = true;
    if (opts.muteDuringAd && video && !mutedByUs) {
      previousMuted = video.muted;
      video.muted = true;
      mutedByUs = true;
    }
  }

  // Restore whatever we changed, so the real clip is untouched.
  function leaveAd(video) {
    adActive = false;
    if (mutedByUs) {
      if (video) video.muted = previousMuted;
      mutedByUs = false;
      previousMuted = false;
    }
  }

  // Fast-forward an un-skippable ad by seeking it to the end. Guarded on the ad
  // actually showing, so it can never seek your real video.
  function fastForward(video) {
    if (!video || !isFinite(video.duration) || video.duration <= 0) return;
    if (video.currentTime >= video.duration - 0.5) return;
    try {
      video.currentTime = video.duration;
    } catch {
      /* YouTube occasionally rejects the seek; the interval retries */
    }
  }

  function tick() {
    if (!opts.enabled) {
      if (adActive) leaveAd(getVideo());
      return;
    }

    const video = getVideo();
    const onAd = adShowing();

    if (onAd && !adActive) enterAd(video);
    else if (!onAd && adActive) leaveAd(video);

    if (opts.hideOverlays) clickFirst(OVERLAY_CLOSE_SELECTORS);
    if (!onAd) return;

    // 1. The main goal: click "Skip Ad" the instant it is clickable.
    if (opts.clickSkip && clickFirst(SKIP_SELECTORS)) {
      bumpCounter();
      return;
    }

    // 2. Skip button not available yet (or un-skippable ad) — run it out.
    if (opts.fastForward) fastForward(video);
  }

  // React on DOM mutations (fast) plus a steady interval (safety net).
  const observer = new MutationObserver(tick);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  const interval = setInterval(tick, 300);

  // Load saved settings, then keep them live.
  try {
    chrome.storage.sync.get(DEFAULTS, (saved) => {
      if (!chrome.runtime.lastError && saved) opts = { ...DEFAULTS, ...saved };
      tick();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync') return;
      for (const [key, { newValue }] of Object.entries(changes)) {
        if (key in opts) opts[key] = newValue;
      }
      tick();
    });
  } catch {
    /* storage unavailable — carry on with defaults */
  }

  window.addEventListener('pagehide', () => {
    observer.disconnect();
    clearInterval(interval);
  });

  tick();
})();
