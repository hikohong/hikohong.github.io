'use strict';

const DEFAULTS = {
  enabled: true,
  clickSkip: true,
  fastForward: true,
  muteDuringAd: true,
  hideOverlays: true,
};

const boxes = Object.keys(DEFAULTS).map((k) => document.getElementById(k));
const countEl = document.getElementById('skipCount');

// Sub-toggles are meaningless while the master switch is off — grey them out.
function syncEnabledState() {
  const on = document.getElementById('enabled').checked;
  for (const box of boxes) {
    if (box.id === 'enabled') continue;
    box.disabled = !on;
    box.closest('.row').style.opacity = on ? '1' : '.45';
  }
}

chrome.storage.sync.get(DEFAULTS, (saved) => {
  for (const box of boxes) box.checked = saved[box.id];
  syncEnabledState();
});

for (const box of boxes) {
  box.addEventListener('change', () => {
    chrome.storage.sync.set({ [box.id]: box.checked });
    if (box.id === 'enabled') syncEnabledState();
  });
}

chrome.storage.local.get({ skipCount: 0 }, ({ skipCount }) => {
  countEl.textContent = skipCount;
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.skipCount) {
    countEl.textContent = changes.skipCount.newValue ?? 0;
  }
});

document.getElementById('reset').addEventListener('click', () => {
  chrome.storage.local.set({ skipCount: 0 });
  countEl.textContent = '0';
});
